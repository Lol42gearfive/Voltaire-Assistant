// content.js
console.log('Projet Voltaire Assistant: Content script loaded.');

let inspectorEnabled = false;
let solveEnabled = false;
let delayMin = 1;
let delayMax = 2;
let dndDelayMin = 1;
let dndDelayMax = 2;
let isSolving = false;
let lastDetectedSentence = '';
let lastDetectedSentenceTime = 0;
let lastAttemptedSentence = '';
let lastAttemptedSentenceTime = 0;
let lastActionClickTime = 0;
let lastPageWasExercise = false;
let movedPhrases = new Set();
let errorRate = 0;

const MIN_CLICK_COOLDOWN = 1200;

function toSeconds(value, fallbackSec) {
    const num = Number(value);
    if (!Number.isFinite(num) || num <= 0) return fallbackSec;
    return num >= 100 ? num / 1000 : num;
}

function applyDelays(dMin, dMax, dndMin, dndMax) {
    const min = toSeconds(dMin, delayMin);
    const max = toSeconds(dMax, delayMax);
    const minDnd = toSeconds(dndMin, dndDelayMin);
    const maxDnd = toSeconds(dndMax, dndDelayMax);

    delayMin = Math.min(min, max);
    delayMax = Math.max(min, max);
    dndDelayMin = Math.min(minDnd, maxDnd);
    dndDelayMax = Math.max(minDnd, maxDnd);
}

chrome.storage.local.get(
    ['delayMin', 'delayMax', 'dndDelayMin', 'dndDelayMax', 'solveEnabled', 'errorRate'],
    (result) => {
        applyDelays(
            result.delayMin ?? 1,
            result.delayMax ?? 2,
            result.dndDelayMin ?? 1,
            result.dndDelayMax ?? 2
        );
        if (result.errorRate !== undefined) errorRate = Number(result.errorRate) || 0;

        solveEnabled = result.solveEnabled || false;
        if (solveEnabled) solveLoop();
    }
);

function incrementStat(type) {
    const key = type === 'correct' ? 'statsCorrect' : 'statsWrong';
    chrome.storage.local.get([key], (result) => {
        chrome.storage.local.set({ [key]: (result[key] || 0) + 1 });
    });
}

const config = {
    wordSelector: 'div[tabindex="0"]',
    buttonSelector: '[data-testid="button"]',
    nextButtonText: ['Suivant', 'Continuer', 'Valider']
};

function getRandomDelaySeconds(isDnd = false) {
    const min = isDnd ? dndDelayMin : delayMin;
    const max = isDnd ? dndDelayMax : delayMax;
    return Math.random() * (max - min) + min;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggleInspector') {
        inspectorEnabled = request.enabled;
        toggleInspectorMode(inspectorEnabled);
    } else if (request.action === 'toggleSolve') {
        solveEnabled = request.enabled;
        if (solveEnabled) solveLoop();
    } else if (request.action === 'updateDelay') {
        applyDelays(
            request.min ?? delayMin,
            request.max ?? delayMax,
            request.dndMin ?? dndDelayMin,
            request.dndMax ?? dndDelayMax
        );
        console.log(
            'Délais mis à jour -> Phrases : ' + delayMin + '-' + delayMax +
            's | Colonnes : ' + dndDelayMin + '-' + dndDelayMax + 's'
        );
    } else if (request.action === 'updateErrorRate') {
        errorRate = Number(request.rate) || 0;
        console.log('Error rate updated: ' + errorRate + '%');
    }
});

function getExercisesFromDOM() {
    document.dispatchEvent(new CustomEvent('__pv_extract'));

    const dataEl = document.getElementById('__pv_exercises');
    if (!dataEl) return null;

    try {
        return JSON.parse(dataEl.getAttribute('data-exercises'));
    } catch (e) {
        return null;
    }
}

function normalizeSentence(str) {
    return str
        .replace(/[\u2018\u2019\u02BC\u0060]/g, "'")
        .replace(/[\u2011\u2010\u2012\u2013\u2014]/g, '-')
        .replace(/\s+/g, ' ')
        .trim()
        .toLowerCase();
}

function stripPunctuation(str) {
    return str.replace(/[.,;:!?()«»""…–—-]/g, '').replace(/\s+/g, ' ').trim();
}

function isElementDisabled(el) {
    if (!el) return true;
    const style = window.getComputedStyle(el);
    return Boolean(
        el.disabled ||
        el.getAttribute('aria-disabled') === 'true' ||
        style.pointerEvents === 'none'
    );
}

function isTopMostElement(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return false;
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    const topEl = document.elementFromPoint(x, y);
    return Boolean(topEl && (el === topEl || el.contains(topEl) || topEl.contains(el)));
}

function canTriggerNavigationClick() {
    return Date.now() - lastActionClickTime >= MIN_CLICK_COOLDOWN;
}

function registerNavigationClick() {
    lastActionClickTime = Date.now();
}

function findCurrentExercise(exercises, displayedWords) {
    if (!exercises || !displayedWords || displayedWords.length === 0) return null;

    const displayedText = normalizeSentence(displayedWords.join(' '));
    const displayedStripped = stripPunctuation(displayedText);

    let bestMatch = null;
    let bestScore = 0;

    for (const ex of exercises) {
        if (!ex.sentence) continue;
        const exText = normalizeSentence(ex.sentence.map(s => stripHtml(s.text)).join(' '));
        const exStripped = stripPunctuation(exText);

        if (exText === displayedText || exStripped === displayedStripped) {
            return ex;
        }

        if (exStripped.includes(displayedStripped) || displayedStripped.includes(exStripped)) {
            return ex;
        }

        const exWords = exStripped.split(/\s+/);
        const dispWords = displayedStripped.split(/\s+/);
        const matchCount = dispWords.filter(w => exWords.includes(w)).length;
        const score = matchCount / Math.max(dispWords.length, exWords.length);
        if (score > bestScore) {
            bestScore = score;
            bestMatch = ex;
        }
    }

    if (bestScore >= 0.6) {
        return bestMatch;
    }

    return null;
}

function getAnswerForExercise(exercise) {
    if (!exercise) return null;

    if (exercise.type === 'click_on_mistake') {
        if (!exercise.hasMistake) {
            return { type: 'no_mistake' };
        }
        for (const part of exercise.sentence) {
            if (part.mistake) {
                return { type: 'click_word', word: stripHtml(part.text) };
            }
        }
    }

    if (exercise.type === 'click_on_word') {
        for (const part of exercise.sentence) {
            if (part.clue) {
                return { type: 'click_word', word: stripHtml(part.text) };
            }
        }
    }

    for (const part of exercise.sentence) {
        if (part.mistake || part.clue) {
            return { type: 'click_word', word: stripHtml(part.text) };
        }
    }

    if (exercise.hasMistake === false) {
        return { type: 'no_mistake' };
    }

    return null;
}

function stripHtml(str) {
    return str.replace(/<[^>]*>/g, '');
}

function isDragAndDropPage() {
    const pageText = document.body ? document.body.innerText : '';
    return pageText.includes('Cliquer / Déposer') || pageText.includes('Cliquer / D\u00e9poser');
}

function handleRuleDifficultyScreen() {
    const pageText = document.body ? normalizeSentence(document.body.innerText) : '';
    const isDifficultyPrompt =
        pageText.includes('cette regle est-elle difficile pour vous') ||
        pageText.includes('cette règle est-elle difficile pour vous');

    if (!isDifficultyPrompt) {
        return false;
    }

    const continueButtons = Array.from(
        document.querySelectorAll('button, [data-testid="button"], div[role="button"]')
    ).filter(btn => {
        if (!isVisible(btn) || isElementDisabled(btn)) return false;
        const rect = btn.getBoundingClientRect();
        if (rect.top < 110 || rect.width < 100 || rect.height < 25) return false;
        const text = (btn.innerText || btn.textContent || '').replace(/[\u00A0\s]+/g, ' ').trim().toUpperCase();
        return text === 'CONTINUER' && isTopMostElement(btn);
    });

    const targetBtn = continueButtons[continueButtons.length - 1] || null;

    if (targetBtn && canTriggerNavigationClick()) {
        console.log('[solveLoop] Modale "Cette règle est-elle difficile pour vous ?" -> clic sur CONTINUER');
        registerNavigationClick();

        const rect = targetBtn.getBoundingClientRect();
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;

        targetBtn.focus();
        targetBtn.click();
        simulateClick(targetBtn);
        document.dispatchEvent(new CustomEvent('__pv_click', { detail: { x, y } }));

        lastDetectedSentence = '';
        lastAttemptedSentence = '';
        movedPhrases.clear();
    }

    return true;
}

function findNoMistakeButton(potentialWords) {
    function normalizeText(str) {
        return str.replace(/[\u2018\u2019\u02BC\u0060]/g, "'");
    }

    let btn = potentialWords.find(el => {
        const text = el.innerText ? normalizeText(el.innerText).replace(/\s+/g, ' ').trim().toUpperCase() : '';
        return (text.includes("IL N'Y A PAS DE FAUTE") || text.includes("PAS DE FAUTE")) && text.length < 30;
    });

    if (!btn) {
        const allBtns = Array.from(
            document.querySelectorAll('[data-testid="button"], button, div[role="button"], div[tabindex="0"]')
        ).filter(isVisible);
        btn = allBtns.find(b => {
            const t = normalizeText(b.innerText || '').replace(/\s+/g, ' ').trim().toUpperCase();
            return (t.includes("IL N'Y A PAS DE FAUTE") || t.includes("PAS DE FAUTE")) && t.length < 35;
        });
    }

    return btn || null;
}

function solveDragAndDrop(exercises) {
    const dndExercises = exercises.filter(ex => ex.type === 'drag_and_drop' || ex.columns);
    if (dndExercises.length === 0) {
        return 'error';
    }
    const htmlElements = Array.from(document.querySelectorAll('[data-testid="html"]')).filter(isVisible);
    const tabElements = Array.from(document.querySelectorAll('div[tabindex="0"]')).filter(el => {
        if (!isVisible(el)) return false;
        const text = (el.innerText || '').trim();
        return text.length > 0 && text.length < 60 && !el.querySelector('svg') &&
        !(text.toUpperCase().includes('VALIDER')) &&
        !(text.toUpperCase().includes('CONTINUER')) &&
        !(text.toUpperCase().includes('SUIVANT')) &&
        !(text.toUpperCase().includes('RETOUR AU MENU'));
    });
    const allCardElements = [...htmlElements, ...tabElements];
    const seen = new Set();
    const uniqueCards = [];
    for (const el of allCardElements) {
        const text = normalizeSentence(el.innerText.trim());
        if (text && !seen.has(text)) {
            seen.add(text);
            uniqueCards.push({ element: el, text: text });
        }
    }
    const pageTexts = uniqueCards.map(c => c.text);
    let currentExercise = null;
    let bestMatchCount = 0;
    for (const ex of dndExercises) {
        if (!ex.columns) continue;
        const allWords = [];
        for (const col of ex.columns) {
            for (const word of col.words) {
                allWords.push(normalizeSentence(stripHtml(word)));
            }
        }
        let matchCount = 0;
        for (const pt of pageTexts) {
            if (allWords.includes(pt)) matchCount++;
        }
        if (matchCount > bestMatchCount) {
            bestMatchCount = matchCount;
            currentExercise = ex;
        }
    }
    if (!currentExercise || bestMatchCount === 0) {
        return 'error';
    }
    const columnNames = currentExercise.columns.map(col => stripHtml(col.instruction));
    const phraseToColumn = {};
    for (const col of currentExercise.columns) {
        const colName = stripHtml(col.instruction);
        for (const word of col.words) {
            phraseToColumn[normalizeSentence(stripHtml(word))] = colName;
        }
    }
    const dropZonesCheck = Array.from(document.querySelectorAll('.r-vacyoi')).filter(isVisible);
    let dropZoneTop = Infinity;
    for (const dz of dropZonesCheck) {
        const r = dz.getBoundingClientRect();
        if (r.top < dropZoneTop) dropZoneTop = r.top;
    }
    const unplacedPhrases = [];
    for (const card of uniqueCards) {
        if (movedPhrases.has(card.text)) continue;
        const clickTarget = card.element.hasAttribute && card.element.hasAttribute('data-testid')
        ? card.element.parentElement : card.element;
        if (!clickTarget) continue;
        const cardRect = clickTarget.getBoundingClientRect();
        if (dropZoneTop < Infinity && cardRect.top >= dropZoneTop - 10) continue;
        const colName = phraseToColumn[card.text];
        if (colName) {
            unplacedPhrases.push({ element: clickTarget, text: card.text, column: colName });
        } else {
            const stripped = stripPunctuation(card.text);
            for (const [phraseKey, cn] of Object.entries(phraseToColumn)) {
                if (stripPunctuation(phraseKey) === stripped) {
                    unplacedPhrases.push({ element: clickTarget, text: card.text, column: cn });
                    break;
                }
            }
        }
    }
    if (unplacedPhrases.length === 0) {
        return 'done';
    }
    let dropZones = Array.from(document.querySelectorAll('.r-vacyoi')).filter(isVisible);
    let zoneMap = [];
    if (dropZones.length >= columnNames.length) {
        dropZones.sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left);
        for (let i = 0; i < columnNames.length; i++) {
            zoneMap.push({ element: dropZones[i], column: columnNames[i] });
        }
    }
    if (zoneMap.length < columnNames.length) {
        zoneMap = [];
        const allDivs = Array.from(document.querySelectorAll('div')).filter(isVisible);
        const colKeywords = columnNames.map(name => {
            const words = name.split(/\s+/);
            return { name: name, keyword: words[words.length - 1].toLowerCase() };
        });
        for (const ck of colKeywords) {
            for (const div of allDivs) {
                const text = (div.innerText || '').toLowerCase();
                const rect = div.getBoundingClientRect();
                const otherKeywords = colKeywords.filter(c => c.keyword !== ck.keyword);
                if (text.includes(ck.keyword) &&
                !otherKeywords.some(ok => text.includes(ok.keyword)) &&
                rect.height > 50 && rect.width > 100) {
                    if (!zoneMap.some(z => z.column === ck.name)) {
                        zoneMap.push({ element: div, column: ck.name });
                        break;
                    }
                }
            }
        }
    }
    if (zoneMap.length === 0) {
        return 'error';
    }
    const phrase = unplacedPhrases[0];
    let targetColumnName = phrase.column;
    const shouldMakeMistake = errorRate > 0 && (Math.random() * 100 < errorRate);
    if (shouldMakeMistake && zoneMap.length > 1) {
        const wrongZones = zoneMap.filter(z => z.column !== phrase.column);
        if (wrongZones.length > 0) {
            const chosenWrong = wrongZones[Math.floor(Math.random() * wrongZones.length)];
            targetColumnName = chosenWrong.column;
            incrementStat('wrong');
        }
    } else {
        incrementStat('correct');
    }
    const targetZone = zoneMap.find(z => z.column === targetColumnName);
    if (!targetZone) {
        return 'error';
    }
    movedPhrases.add(phrase.text);
    simulateClick(phrase.element);
    setTimeout(() => {
        simulateClick(targetZone.element);
    }, 400);
    return 'moved';
}

function findEndOfLevelButton() {
    const clickable = Array.from(
        document.querySelectorAll('button, [data-testid="button"], div[role="button"], div[tabindex="0"]')
    ).filter(isVisible);
    return clickable.find(btn => {
        if (isElementDisabled(btn)) return false;
        const rect = btn.getBoundingClientRect();
        if (rect.top < 110 && rect.left < 260) return false;
        const text = (btn.innerText || btn.textContent || '').replace(/\s+/g, ' ').trim().toUpperCase();
        if (!text || text.length > 45) return false;
        return (text.includes('RETOUR AU MENU') ||
        text.includes("RETOUR A L'ACCUEIL") ||
        text.includes("RETOUR À L'ACCUEIL") ||
        text.includes('CHANGER DE NIVEAU') ||
        text.includes('NIVEAU SUIVANT') ||
        text.includes('MODULE SUIVANT') ||
        text.includes('EXERCICE SUIVANT') ||
        text.includes('TERMINER')) && isTopMostElement(btn);
    }) || null;
}

function solveLoop() {
    if (!solveEnabled) return;
    if (isSolving) { setTimeout(solveLoop, 500); return; }
    const isDnd = isDragAndDropPage();
    const currentDelaySec = getRandomDelaySeconds(isDnd);
    const currentDelayMs = Math.round(currentDelaySec * 1000);
    
    const pageTextFull = document.body ? document.body.innerText.toUpperCase() : '';
    const isLevelCompletedScreen = pageTextFull.includes('BRAVO') || pageTextFull.includes('NIVEAU TERMINÉ') || pageTextFull.includes('EXCELLENT');

    const endLevelBtnOnExercise = findEndOfLevelButton();
    if ((endLevelBtnOnExercise || isLevelCompletedScreen) && canTriggerNavigationClick()) {
        const targetBtn = endLevelBtnOnExercise || Array.from(document.querySelectorAll('button, [data-testid="button"], div[role="button"], div[tabindex="0"]')).filter(isVisible).find(b => isTopMostElement(b) && !isElementDisabled(b));
        if (targetBtn) {
            console.log('[solveLoop] Fin de niveau détectée (Bravo/Menu), clic sur :', targetBtn.innerText.trim());
            registerNavigationClick();
            simulateClick(targetBtn);
            targetBtn.click();
            movedPhrases.clear();
            lastDetectedSentence = '';
            lastAttemptedSentence = '';
            setTimeout(solveLoop, 2500);
            return;
        }
    }

    const isExercisePage = window.location.href.includes('/exercice') || window.location.href.includes('/entrainement');
    if (!isExercisePage) {
        lastPageWasExercise = false;
        const nextLevelBtn = findEndOfLevelButton() || Array.from(
            document.querySelectorAll('button, [data-testid="button"], div[role="button"]')
        ).filter(isVisible).find(btn => {
            if (isElementDisabled(btn)) return false;
            const rect = btn.getBoundingClientRect();
            if (rect.top < 110 && rect.left < 260) return false;
            const text = (btn.innerText || btn.textContent || '').replace(/\s+/g, ' ').trim().toUpperCase();
            return (text === 'COMMENCER' || text === 'DÉMARRER' || text === 'CONTINUER') && isTopMostElement(btn);
        });
        if (nextLevelBtn && canTriggerNavigationClick()) {
            console.log('[solveLoop] Menu/Fin de niveau détecté, clic sur :', nextLevelBtn.innerText.trim());
            registerNavigationClick();
            simulateClick(nextLevelBtn);
        }
        setTimeout(solveLoop, 2000);
        return;
    }

    if (!lastPageWasExercise) {
        lastPageWasExercise = true;
        chrome.storage.local.set({ statsCorrect: 0, statsWrong: 0 });
        console.log('[solveLoop] Nouvelle session détectée, compteurs remis à zéro');
    }

    if (handleRuleDifficultyScreen()) {
        setTimeout(solveLoop, currentDelayMs);
        return;
    }

    if (isDnd) {
        const allClickable = [
            ...Array.from(document.querySelectorAll('button')),
            ...Array.from(document.querySelectorAll('[data-testid="button"]'))
        ].filter(el => isVisible(el) && !isElementDisabled(el));
        const nextBtn = allClickable.find(btn => {
            const rect = btn.getBoundingClientRect();
            if (rect.top < 110 && rect.left < 260) return false;
            const text = (btn.innerText || '').replace(/\s+/g, ' ').trim().toUpperCase();
            return (text === 'SUIVANT' || text === 'CONTINUER') && isTopMostElement(btn);
        });
        if (nextBtn && canTriggerNavigationClick()) {
            console.log('[D&D] Clicking SUIVANT/CONTINUER');
            registerNavigationClick();
            simulateClick(nextBtn);
            movedPhrases.clear();
            lastDetectedSentence = '';
            setTimeout(solveLoop, currentDelayMs);
            return;
        }
        const exercises = getExercisesFromDOM();
        if (exercises) {
            isSolving = true;
            let dndResult;
            try {
                dndResult = solveDragAndDrop(exercises);
            } finally {
                isSolving = false;
            }
            if (dndResult === 'moved') {
                setTimeout(solveLoop, currentDelayMs + 600);
                return;
            }
            if (dndResult === 'done') {
                const validerBtn = allClickable.find(btn => {
                    const text = (btn.innerText || '').replace(/\s+/g, ' ').trim().toUpperCase();
                    return text === 'VALIDER' && isTopMostElement(btn);
                });
                if (validerBtn && canTriggerNavigationClick()) {
                    console.log('[D&D] All placed, clicking VALIDER');
                    registerNavigationClick();
                    simulateClick(validerBtn);
                    setTimeout(solveLoop, currentDelayMs + 1000);
                    return;
                }
            }
        }
        setTimeout(solveLoop, currentDelayMs);
        return;
    }

    const allButtons = Array.from(document.querySelectorAll('button')).filter(
        btn => isVisible(btn) && !isElementDisabled(btn)
    );
    const disableBtn = allButtons.find(btn => {
        const text = (btn.innerText || '').replace(/\s+/g, ' ').trim().toUpperCase();
        return text === 'DÉSACTIVER' || text === 'DESACTIVER';
    });
    if (disableBtn && canTriggerNavigationClick()) {
        registerNavigationClick();
        disableBtn.click();
        setTimeout(solveLoop, currentDelayMs);
        return;
    }
    const cantListenBtn = allButtons.find(btn => {
        const text = (btn.innerText || '').replace(/\s+/g, ' ').trim().toUpperCase();
        return text.includes('NE PEUX PAS') || text.includes('PAS ÉCOUTER') || text.includes('PAS ECOUTER');
    });
    if (cantListenBtn && canTriggerNavigationClick()) {
        registerNavigationClick();
        cantListenBtn.click();
        setTimeout(solveLoop, currentDelayMs);
        return;
    }

    const clickableWords = document.querySelectorAll('div[tabindex="0"]');
    const hasExerciseWords = Array.from(clickableWords).some(el => {
        if (!isVisible(el)) return false;
        const rect = el.getBoundingClientRect();
        if (rect.top < 110 && rect.left < 260) return false;
        const text = (el.innerText || '').replace(/\s+/g, ' ').trim();
        const upper = text.toUpperCase();
        return text.length > 0 && text.length < 40 && !el.querySelector('svg') &&
        !upper.includes('RETOUR AU MENU') &&
        upper !== 'CONTINUER' &&
        upper !== 'SUIVANT' &&
        upper !== 'VALIDER';
    });

    if (!hasExerciseWords) {
        const skipButton = allButtons.find(btn => {
            const rect = btn.getBoundingClientRect();
            if (rect.top < 110 && rect.left < 260) return false;
            const text = (btn.innerText || btn.textContent || '').replace(/\s+/g, ' ').trim().toUpperCase();
            return (text === 'CONTINUER' || text === 'SUIVANT' || text === 'RETOUR AU MENU') && isTopMostElement(btn);
        });
        if (skipButton && canTriggerNavigationClick()) {
            console.log('Non-exercise screen detected. Clicking:', skipButton.innerText.trim());
            registerNavigationClick();
            simulateClick(skipButton);
            lastDetectedSentence = '';
            lastAttemptedSentence = '';
            movedPhrases.clear();
            setTimeout(solveLoop, currentDelayMs);
            return;
        }
    }

    const correctionButton = allButtons.find(btn => {
        const rect = btn.getBoundingClientRect();
        if (rect.top < 110 && rect.left < 260) return false;
        const text = (btn.innerText || btn.textContent || '').replace(/\s+/g, ' ').trim().toUpperCase();
        return text === 'SUIVANT' && isTopMostElement(btn);
    });
    if (correctionButton && canTriggerNavigationClick()) {
        registerNavigationClick();
        simulateClick(correctionButton);
        lastDetectedSentence = '';
        lastAttemptedSentence = '';
        movedPhrases.clear();
        setTimeout(solveLoop, currentDelayMs);
        return;
    }

    const dataTestButtons = Array.from(document.querySelectorAll(config.buttonSelector)).filter(
        btn => isVisible(btn) && !isElementDisabled(btn)
    );
    const actionButton = dataTestButtons.find(btn => {
        const rect = btn.getBoundingClientRect();
        if (rect.top < 110 && rect.left < 260) return false;
        const text = (btn.innerText || btn.textContent || '').replace(/\s+/g, ' ').trim();
        return config.nextButtonText.some(t => text.toUpperCase() === t.toUpperCase()) && isTopMostElement(btn);
    });
    if (actionButton && canTriggerNavigationClick()) {
        registerNavigationClick();
        actionButton.click();
        lastDetectedSentence = '';
        lastAttemptedSentence = '';
        setTimeout(solveLoop, currentDelayMs);
        return;
    }

    const potentialWords = Array.from(document.querySelectorAll(config.wordSelector)).filter(isVisible);
    function normalizeText(str) {
        return str.replace(/[\u2018\u2019\u02BC\u0060]/g, "'");
    }
    const noMistakeButton = findNoMistakeButton(potentialWords);
    const sentenceWords = potentialWords.filter(el => {
        const text = el.innerText ? el.innerText.trim() : '';
        const upperText = normalizeText(text).toUpperCase();
        if (noMistakeButton && el === noMistakeButton) return false;
        return text.length > 0 &&
        text.length < 40 &&
        !el.querySelector('svg') &&
        !el.closest('[data-testid="html"]') &&
        !upperText.includes('COUP DE POUCE') &&
        !upperText.includes('PAS DE FAUTE') &&
        !upperText.includes('RETOUR AU MENU') &&
        !upperText.includes('SUIVANT') &&
        !upperText.includes('CONTINUER') &&
        !upperText.includes('VALIDER');
    });

    if (sentenceWords.length > 0) {
        const fullSentence = sentenceWords.map(w => w.innerText.trim()).join(' ');
        const alreadyAttempted = (fullSentence === lastAttemptedSentence) && (Date.now() - lastAttemptedSentenceTime < 6000);
        if (alreadyAttempted) {
            setTimeout(solveLoop, currentDelayMs);
            return;
        }
        const sentenceChanged = fullSentence !== lastDetectedSentence;
        const sentenceStalled = !sentenceChanged && (Date.now() - lastDetectedSentenceTime > 10000);
        if (sentenceStalled) {
            lastDetectedSentence = '';
        }
        if (sentenceChanged || sentenceStalled) {
            isSolving = true;
            try {
                const exercises = getExercisesFromDOM();
                if (exercises) {
                    const displayedWords = sentenceWords.map(w => w.innerText.trim());
                    const currentExercise = findCurrentExercise(exercises, displayedWords);
                    if (currentExercise) {
                        const answer = getAnswerForExercise(currentExercise);
                        const shouldMakeMistake = errorRate > 0 && (Math.random() * 100 < errorRate);
                        let actionTaken = false;
                        if (shouldMakeMistake && sentenceWords.length > 1) {
                            if (answer && answer.type === 'no_mistake') {
                                const randomWord = sentenceWords[Math.floor(Math.random() * sentenceWords.length)];
                                simulateClick(randomWord);
                                incrementStat('wrong');
                                actionTaken = true;
                            } else if (answer && answer.type === 'click_word') {
                                if (noMistakeButton && Math.random() < 0.5) {
                                    const rect = noMistakeButton.getBoundingClientRect();
                                    document.dispatchEvent(new CustomEvent('__pv_click', {
                                        detail: { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 }
                                    });
                                    incrementStat('wrong');
                                    actionTaken = true;
                                } else {
                                    const wrongWords = sentenceWords.filter(w =>
                                        normalizeSentence(w.innerText.trim()) !== normalizeSentence(answer.word)
                                    );
                                    if (wrongWords.length > 0) {
                                        const randomWrong = wrongWords[Math.floor(Math.random() * wrongWords.length)];
                                        simulateClick(randomWrong);
                                        incrementStat('wrong');
                                        actionTaken = true;
                                    }
                                }
                            }
                        } else if (answer && answer.type === 'no_mistake') {
                            if (noMistakeButton) {
                                const rect = noMistakeButton.getBoundingClientRect();
                                document.dispatchEvent(new CustomEvent('__pv_click', {
                                    detail: { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 }
                                }));
                                incrementStat('correct');
                                actionTaken = true;
                            }
                        } else if (answer && answer.type === 'click_word') {
                            const normalizedAnswer = normalizeSentence(answer.word);
                            let targetWord = sentenceWords.find(w =>
                                normalizeSentence(w.innerText.trim()) === normalizedAnswer
                            );
                            if (!targetWord) {
                                const answerWords = normalizedAnswer.split(/\s+/);
                                targetWord = sentenceWords.find(w => {
                                    const norm = normalizeSentence(w.innerText.trim());
                                    return answerWords.includes(norm);
                                });
                            }
                            if (targetWord) {
                                simulateClick(targetWord);
                                incrementStat('correct');
                                actionTaken = true;
                            }
                        }
                        if (actionTaken) {
                            lastDetectedSentence = fullSentence;
                            lastDetectedSentenceTime = Date.now();
                            lastAttemptedSentence = fullSentence;
                            lastAttemptedSentenceTime = Date.now();
                        }
                    }
                }
            } finally {
                isSolving = false;
            }
        }
    }
    if (solveEnabled) {
        setTimeout(solveLoop, currentDelayMs);
    }
}

function simulateClick(element) {
    const rect = element.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    const options = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };
    element.dispatchEvent(new PointerEvent('pointerdown', { ...options, pointerId: 1 }));
    element.dispatchEvent(new MouseEvent('mousedown', options));
    element.dispatchEvent(new PointerEvent('pointerup', { ...options, pointerId: 1 }));
    element.dispatchEvent(new MouseEvent('mouseup', options));
    element.dispatchEvent(new MouseEvent('click', options));
}

function isVisible(elem) {
    if (!elem) return false;
    const style = window.getComputedStyle(elem);
    return !!(elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length) &&
    style.visibility !== 'hidden' &&
    style.display !== 'none' &&
    style.opacity !== '0';
}

let lastHighlighted = null;
function toggleInspectorMode(enabled) {
    if (enabled) {
        document.body.style.cursor = 'crosshair';
        document.addEventListener('mouseover', highlightElement);
        document.addEventListener('click', logElementInfo);
    } else {
        document.body.style.cursor = 'default';
        document.removeEventListener('mouseover', highlightElement);
        document.removeEventListener('click', logElementInfo);
        removeHighlight();
    }
}

function highlightElement(e) {
    if (lastHighlighted) lastHighlighted.style.outline = '';
    e.target.style.outline = '2px solid red';
    lastHighlighted = e.target;
}

function removeHighlight() {
    if (lastHighlighted) {
        lastHighlighted.style.outline = '';
        lastHighlighted = null;
    }
}

function logElementInfo(e) {
    e.preventDefault();
    e.stopPropagation();
    const el = e.target;
    const tag = el.tagName.toLowerCase();
    const id = el.id ? '#' + el.id : '';
    const classes = el.className && typeof el.className === 'string' ? '.' + el.className.split(' ').join('.') : '';
    const testId = el.getAttribute('data-testid') ? '[data-testid="' + el.getAttribute('data-testid') + '"]' : '';
    const selector = testId || (tag + id + classes);
    console.log('Selected Element:', selector);
    console.log('Inner Text:', el.innerText);
    chrome.runtime.sendMessage({ action: 'logSelector', selector });
}