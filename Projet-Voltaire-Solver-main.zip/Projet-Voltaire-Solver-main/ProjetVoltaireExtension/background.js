
// background.js

let previousZoom = null;
let zoomTabId = null;

chrome.runtime.onInstalled.addListener(() => {
    console.log('Projet Voltaire Assistant installed.');
});

function isProjetVoltaireUrl(url) {
    if (!url) return false;
    try {
        const parsed = new URL(url);
        return /(^|\.)(projet-voltaire|groupe-voltaire)\.fr$/i.test(parsed.hostname);
    } catch (e) {
        return false;
    }
}

// Appliquer le zoom à 80 % automatiquement sur Projet Voltaire
const applyZoom = async (tabId, url) => {
    if (!isProjetVoltaireUrl(url)) return;

    try {
        if (zoomTabId !== tabId || previousZoom === null) {
            previousZoom = await chrome.tabs.getZoom(tabId);
            zoomTabId = tabId;
        }
        await chrome.tabs.setZoom(tabId, 0.8);
    } catch (error) {
        console.error("Impossible d'appliquer le zoom :", error);
    }
};

// Activer le zoom à 80 % manuellement pour un onglet
async function activateZoom(tabId) {
    try {
        const tab = await chrome.tabs.get(tabId);
        if (!isProjetVoltaireUrl(tab.url)) return;

        previousZoom = await chrome.tabs.getZoom(tabId);
        zoomTabId = tabId;

        await chrome.tabs.setZoom(tabId, 0.8);
    } catch (error) {
        console.error("Impossible d'activer le zoom :", error);
    }
}

// Restaurer le zoom précédent
async function restoreZoom() {
    if (zoomTabId === null || previousZoom === null) return;

    try {
        await chrome.tabs.setZoom(zoomTabId, previousZoom);
    } catch (error) {
        console.error("Impossible de restaurer le zoom :", error);
    } finally {
        previousZoom = null;
        zoomTabId = null;
    }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        applyZoom(tabId, tab.url);
    }
});

chrome.tabs.onCreated.addListener((tab) => {
    if (tab.id && tab.url) {
        applyZoom(tab.id, tab.url);
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'activateZoom' && request.tabId) {
        activateZoom(request.tabId);
    } else if (request.action === 'restoreZoom') {
        restoreZoom();
    }
});
