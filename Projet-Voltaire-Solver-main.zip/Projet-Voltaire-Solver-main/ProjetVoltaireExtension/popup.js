// popup.js
document.addEventListener('DOMContentLoaded', () => {
    const playPauseBtn = document.getElementById('playPauseBtn');
    const playPauseIcon = document.getElementById('playPauseIcon');
    const playPauseLabel = document.getElementById('playPauseLabel');
    const statusText = document.getElementById('statusText');
    const themeSelect = document.getElementById('themeSelect');

    const settingsBtn = document.getElementById('settingsBtn');
    const backHomeBtn = document.getElementById('backHomeBtn');
    const homeView = document.getElementById('homeView');
    const settingsView = document.getElementById('settingsView');

    const generalDelayInput = document.getElementById('generalDelay');
    const generalDelayValue = document.getElementById('generalDelayValue');

    const delayMinInput = document.getElementById('delayMin');
    const delayMaxInput = document.getElementById('delayMax');
    const dndDelayMinInput = document.getElementById('dndDelayMin');
    const dndDelayMaxInput = document.getElementById('dndDelayMax');

    const errorRateInput = document.getElementById('errorRate');
    const errorRateValue = document.getElementById('errorRateValue');
    const delayWarning = document.getElementById('delayWarning');

    const accuracyFill = document.getElementById('accuracyFill');
    const resetStatsBtn = document.getElementById('resetStatsBtn');

    let isRunning = false;

    // Navigation entre vues
    settingsBtn.addEventListener('click', () => {
        homeView.classList.remove('active-view');
        settingsView.classList.add('active-view');
    });

    backHomeBtn.addEventListener('click', () => {
        settingsView.classList.remove('active-view');
        homeView.classList.add('active-view');
    });

    // Mise à jour visuelle du bouton Lecture / Pause
    function updatePlayPauseUI(running) {
        isRunning = running;
        if (running) {
            document.body.classList.add('active');
            playPauseBtn.classList.add('is-running');
            playPauseIcon.textContent = '⏸';
            playPauseLabel.textContent = 'Mettre en pause';
            statusText.textContent = 'En cours d\'exécution';
        } else {
            document.body.classList.remove('active');
            playPauseBtn.classList.remove('is-running');
            playPauseIcon.textContent = '▶';
            playPauseLabel.textContent = 'Lancer la résolution';
            statusText.textContent = 'En pause';
        }
    }

    // Gestion des thèmes
    chrome.storage.local.get(['selectedTheme'], (result) => {
        const theme = result.selectedTheme || 'dark';
        themeSelect.value = theme;
        document.body.dataset.theme = theme;
    });

    themeSelect.addEventListener('change', () => {
        const theme = themeSelect.value;
        document.body.dataset.theme = theme;
        chrome.storage.local.set({ selectedTheme: theme });
    });

    function formatToSeconds(val, defaultVal) {
        if (val === undefined || val === null || isNaN(val)) return defaultVal;
        return val >= 100 ? val / 1000 : val;
    }

    // Chargement des paramètres stockés
    chrome.storage.local.get([
        'solveEnabled',
        'generalDelay',
        'delayMin',
        'delayMax',
        'dndDelayMin',
        'dndDelayMax',
        'errorRate'
    ], (result) => {
        updatePlayPauseUI(result.solveEnabled || false);

        const genDelay = formatToSeconds(result.generalDelay, 1.5);
        generalDelayInput.value = genDelay;
        generalDelayValue.textContent = genDelay;

        // Si des valeurs spécifiques sont configurées, on les affiche, sinon les champs restent vides (fallback dynamique)
        if (result.delayMin !== undefined && result.delayMin !== '') delayMinInput.value = formatToSeconds(result.delayMin, '');
        if (result.delayMax !== undefined && result.delayMax !== '') delayMaxInput.value = formatToSeconds(result.delayMax, '');
        if (result.dndDelayMin !== undefined && result.dndDelayMin !== '') dndDelayMinInput.value = formatToSeconds(result.dndDelayMin, '');
        if (result.dndDelayMax !== undefined && result.dndDelayMax !== '') dndDelayMaxInput.value = formatToSeconds(result.dndDelayMax, '');

        if (result.errorRate !== undefined) {
            errorRateInput.value = result.errorRate;
            errorRateValue.textContent = result.errorRate;
        }
    });

    // Clic sur Lecture / Pause
    playPauseBtn.addEventListener('click', () => {
        const nextState = !isRunning;
        updatePlayPauseUI(nextState);
        chrome.storage.local.set({ solveEnabled: nextState });
        sendSettingsToContent();
    });

    // Modification de la vitesse générale depuis l'accueil
    generalDelayInput.addEventListener('input', () => {
        generalDelayValue.textContent = generalDelayInput.value;
    });

    generalDelayInput.addEventListener('change', () => {
        saveAndApplySettings();
    });

    // Modification des paramètres avancés
    delayMinInput.addEventListener('change', saveAndApplySettings);
    delayMaxInput.addEventListener('change', saveAndApplySettings);
    dndDelayMinInput.addEventListener('change', saveAndApplySettings);
    dndDelayMaxInput.addEventListener('change', saveAndApplySettings);

    function saveAndApplySettings() {
        const genVal = Number(generalDelayInput.value) || 1.5;
        
        let min = delayMinInput.value !== '' ? Number(delayMinInput.value) : genVal;
        let max = delayMaxInput.value !== '' ? Number(delayMaxInput.value) : genVal;
        let dndMin = dndDelayMinInput.value !== '' ? Number(dndDelayMinInput.value) : genVal;
        let dndMax = dndDelayMaxInput.value !== '' ? Number(dndDelayMaxInput.value) : genVal;

        let warning = '';
        if (min > max) { max = min; delayMaxInput.value = max; warning = 'Max phrases ajusté.'; }
        if (dndMin > dndMax) { dndMax = dndMin; dndDelayMaxInput.value = dndMax; warning = 'Max colonnes ajusté.'; }

        delayWarning.textContent = warning;
        delayWarning.style.display = warning ? 'block' : 'none';

        chrome.storage.local.set({
            generalDelay: genVal,
            delayMin: delayMinInput.value !== '' ? min : '',
            delayMax: delayMaxInput.value !== '' ? max : '',
            dndDelayMin: dndDelayMinInput.value !== '' ? dndMin : '',
            dndDelayMax: dndDelayMaxInput.value !== '' ? dndMax : ''
        });

        sendSettingsToContent();
    }

    function sendSettingsToContent() {
        const genVal = Number(generalDelayInput.value) || 1.5;
        const min = delayMinInput.value !== '' ? Number(delayMinInput.value) : genVal;
        const max = delayMaxInput.value !== '' ? Number(delayMaxInput.value) : genVal;
        const dndMin = dndDelayMinInput.value !== '' ? Number(dndDelayMinInput.value) : genVal;
        const dndMax = dndDelayMaxInput.value !== '' ? Number(dndDelayMaxInput.value) : genVal;
        const rate = parseInt(errorRateInput.value, 10) || 0;

        sendMessageToContent({
            action: 'updateSettings',
            solveEnabled: isRunning,
            min: min,
            max: max,
            dndMin: dndMin,
            dndMax: dndMax,
            rate: rate
        });
    }

    // Taux d'erreur
    errorRateInput.addEventListener('input', () => {
        errorRateValue.textContent = errorRateInput.value;
    });

    errorRateInput.addEventListener('change', () => {
        saveAndApplySettings();
    });

    // Statistiques
    function updateStats() {
        chrome.storage.local.get(['statsCorrect', 'statsWrong'], (result) => {
            const correct = result.statsCorrect || 0;
            const wrong = result.statsWrong || 0;
            const total = correct + wrong;

            document.getElementById('statCorrect').textContent = correct;
            document.getElementById('statWrong').textContent = wrong;
            document.getElementById('statTotal').textContent = total;

            const ratio = total > 0 ? Math.round((correct / total) * 100) : 100;
            accuracyFill.style.width = ratio + '%';
        });
    }

    updateStats();
    setInterval(updateStats, 1500);

    resetStatsBtn.addEventListener('click', () => {
        chrome.storage.local.set({ statsCorrect: 0, statsWrong: 0 }, () => {
            updateStats();
        });
    });

    function sendMessageToContent(message) {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0] && tabs[0].id) {
                const url = tabs[0].url || '';
                if (url.includes('projet-voltaire.fr') || url.includes('groupe-voltaire.fr') || url.includes('localhost') || url.includes('file://')) {
                    chrome.tabs.sendMessage(tabs[0].id, message, () => {
                        if (chrome.runtime.lastError) {
                            console.debug('Voltaire Assistant : En attente du script de contenu.', chrome.runtime.lastError.message);
                        }
                    });
                }
            }
        });
    }
});