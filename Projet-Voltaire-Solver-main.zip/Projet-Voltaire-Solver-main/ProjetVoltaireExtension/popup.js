
// popup.js
document.addEventListener('DOMContentLoaded', () => {
    const solveToggle = document.getElementById('solveToggle');

    const delayMinInput = document.getElementById('delayMin');
    const delayMaxInput = document.getElementById('delayMax');
    const dndDelayMinInput = document.getElementById('dndDelayMin');
    const dndDelayMaxInput = document.getElementById('dndDelayMax');

    const errorRateInput = document.getElementById('errorRate');
    const errorRateValue = document.getElementById('errorRateValue');

    const delayWarning = document.getElementById('delayWarning');

    // Chargement des paramètres
    chrome.storage.local.get([
        'solveEnabled',
        'delayMin',
        'delayMax',
        'dndDelayMin',
        'dndDelayMax',
        'errorRate'
    ], (result) => {
        solveToggle.checked = result.solveEnabled || false;

        if (result.delayMin !== undefined) delayMinInput.value = result.delayMin;
        if (result.delayMax !== undefined) delayMaxInput.value = result.delayMax;
        if (result.dndDelayMin !== undefined) dndDelayMinInput.value = result.dndDelayMin;
        if (result.dndDelayMax !== undefined) dndDelayMaxInput.value = result.dndDelayMax;

        if (result.errorRate !== undefined) {
            errorRateInput.value = result.errorRate;
            errorRateValue.textContent = result.errorRate;
        }
    });

    // Statistiques
    function updateStats() {
        chrome.storage.local.get(['statsCorrect', 'statsWrong'], (result) => {
            const correct = result.statsCorrect || 0;
            const wrong = result.statsWrong || 0;

            document.getElementById('statCorrect').textContent = correct;
            document.getElementById('statWrong').textContent = wrong;
            document.getElementById('statTotal').textContent = correct + wrong;
        });
    }

    updateStats();
    setInterval(updateStats, 2000);

    // Activation de l'assistant
    solveToggle.addEventListener('change', () => {
        const enabled = solveToggle.checked;

        chrome.storage.local.set({ solveEnabled: enabled });

        sendMessageToContent({
            action: 'toggleSolve',
            enabled: enabled
        });
    });

    // Gestion des délais (saisie en secondes)
    const MIN_DELAY_SECONDS = 1;
    const DEFAULT_DELAY_SECONDS = 2;

    function validateAndUpdateDelays() {
        let min = Number(delayMinInput.value);
        let max = Number(delayMaxInput.value);
        let dndMin = Number(dndDelayMinInput.value);
        let dndMax = Number(dndDelayMaxInput.value);

        let warning = '';

        // Valeurs par défaut si le champ est vide ou invalide
        if (!Number.isFinite(min) || min < MIN_DELAY_SECONDS) {
            min = MIN_DELAY_SECONDS;
            delayMinInput.value = min;
            warning = 'Minimum 1 seconde.';
        }

        if (!Number.isFinite(max) || max < MIN_DELAY_SECONDS) {
            max = DEFAULT_DELAY_SECONDS;
            delayMaxInput.value = max;
            warning = 'Minimum 1 seconde.';
        }

        if (!Number.isFinite(dndMin) || dndMin < MIN_DELAY_SECONDS) {
            dndMin = MIN_DELAY_SECONDS;
            dndDelayMinInput.value = dndMin;
            warning = 'Minimum 1 seconde.';
        }

        if (!Number.isFinite(dndMax) || dndMax < MIN_DELAY_SECONDS) {
            dndMax = DEFAULT_DELAY_SECONDS;
            dndDelayMaxInput.value = dndMax;
            warning = 'Minimum 1 seconde.';
        }

        if (min > max) {
            max = min;
            delayMaxInput.value = max;
            warning = 'Max ajusté au min.';
        }

        if (dndMin > dndMax) {
            dndMax = dndMin;
            dndDelayMaxInput.value = dndMax;
            warning = 'Max colonnes ajusté au min.';
        }

        delayWarning.textContent = warning;
        delayWarning.style.display = warning ? 'block' : 'none';

        // Conversion secondes -> millisecondes
        const minMs = min * 1000;
        const maxMs = max * 1000;
        const dndMinMs = dndMin * 1000;
        const dndMaxMs = dndMax * 1000;

        // Stockage des valeurs en secondes pour le popup
        chrome.storage.local.set({
            delayMin: min,
            delayMax: max,
            dndDelayMin: dndMin,
            dndDelayMax: dndMax
        });

        // Envoi des valeurs converties au script de la page
        sendMessageToContent({
            action: 'updateDelay',
            min: minMs,
            max: maxMs,
            dndMin: dndMinMs,
            dndMax: dndMaxMs
        });
    }

    delayMinInput.addEventListener('change', validateAndUpdateDelays);
    delayMaxInput.addEventListener('change', validateAndUpdateDelays);
    dndDelayMinInput.addEventListener('change', validateAndUpdateDelays);
    dndDelayMaxInput.addEventListener('change', validateAndUpdateDelays);

    // Taux d'erreur
    errorRateInput.addEventListener('input', () => {
        errorRateValue.textContent = errorRateInput.value;
    });

    errorRateInput.addEventListener('change', () => {
        const rate = parseInt(errorRateInput.value, 10);

        chrome.storage.local.set({ errorRate: rate });

        sendMessageToContent({
            action: 'updateErrorRate',
            rate: rate
        });
    });

    // Communication avec le script de la page
    function sendMessageToContent(message) {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                chrome.tabs.sendMessage(tabs[0].id, message);
            }
        });
    }
});
